package librarymanagement.employeemanagementsystem_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystem2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
