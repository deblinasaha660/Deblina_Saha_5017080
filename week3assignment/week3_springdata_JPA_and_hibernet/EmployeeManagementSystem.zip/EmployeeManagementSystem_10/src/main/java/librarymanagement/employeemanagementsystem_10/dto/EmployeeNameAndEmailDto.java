package librarymanagement.employeemanagementsystem_10.dto;

public class EmployeeNameAndEmailDto {
    private String name;
    private String email;

    public EmployeeNameAndEmailDto(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Getters and setters omitted for brevity
}
