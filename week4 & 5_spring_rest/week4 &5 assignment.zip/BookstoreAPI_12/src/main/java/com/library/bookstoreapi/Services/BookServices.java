package com.library.bookstoreapi.Services;

import com.library.bookstoreapi.model.Book;

public class BookServices
{

    public Book findBookById(Long id) {
        return null;
    }
}
