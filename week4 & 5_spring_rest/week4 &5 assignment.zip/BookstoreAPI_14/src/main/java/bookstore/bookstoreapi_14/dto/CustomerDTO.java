package bookstore.bookstoreapi_14.dto;

public class CustomerDTO {
    private Long id;
    private String name;
    private String email;
}
