package bookstore.bookstoreapi_13.dto;

public class CustomerDTO {
    private Long id;
    private String name;
    private String email;
}
