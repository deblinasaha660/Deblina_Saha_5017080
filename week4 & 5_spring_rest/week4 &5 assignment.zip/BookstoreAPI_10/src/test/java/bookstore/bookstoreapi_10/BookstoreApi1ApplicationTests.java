package bookstore.bookstoreapi_10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApi1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
