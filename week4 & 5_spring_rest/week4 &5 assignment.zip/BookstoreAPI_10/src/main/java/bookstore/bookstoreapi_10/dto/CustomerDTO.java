package bookstore.bookstoreapi_10.dto;

public class CustomerDTO {
    private Long id;
    private String name;
    private String email;
}
