package bookstore.bookstoreapi_8.dto;

public class CustomerDTO {
    private Long id;
    private String name;
    private String email;
}
